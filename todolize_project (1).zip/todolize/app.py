from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date, timedelta
import json
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'todolize-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todolize.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ─── Models ───────────────────────────────────────────────────────────────────

class Task(db.Model):
    id          = db.Column(db.Integer, primary_key=True)
    title       = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default='')
    category    = db.Column(db.String(50), default='Personal')
    due_date    = db.Column(db.Date, nullable=True)
    due_time    = db.Column(db.String(10), nullable=True)
    is_completed= db.Column(db.Boolean, default=False)
    is_special  = db.Column(db.Boolean, default=False)
    repeat      = db.Column(db.String(20), default='none')   # none/daily/weekly/monthly
    notes       = db.Column(db.Text, default='')
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at= db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'category': self.category,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'due_time': self.due_time,
            'is_completed': self.is_completed,
            'is_special': self.is_special,
            'repeat': self.repeat,
            'notes': self.notes,
            'created_at': self.created_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
        }


class Reminder(db.Model):
    id          = db.Column(db.Integer, primary_key=True)
    title       = db.Column(db.String(200), nullable=False)
    reminder_type = db.Column(db.String(20), default='reminder')  # birthday/meeting/special/reminder
    reminder_date = db.Column(db.Date, nullable=False)
    reminder_time = db.Column(db.String(10), nullable=True)
    notes       = db.Column(db.Text, default='')
    repeat_yearly = db.Column(db.Boolean, default=False)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'reminder_type': self.reminder_type,
            'reminder_date': self.reminder_date.isoformat(),
            'reminder_time': self.reminder_time,
            'notes': self.notes,
            'repeat_yearly': self.repeat_yearly,
        }

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')

# Tasks API
@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    category = request.args.get('category', 'all')
    date_str  = request.args.get('date')
    q = Task.query
    if category and category != 'all':
        q = q.filter_by(category=category)
    if date_str:
        try:
            d = date.fromisoformat(date_str)
            q = q.filter_by(due_date=d)
        except ValueError:
            pass
    tasks = q.order_by(Task.due_date.asc(), Task.due_time.asc()).all()
    return jsonify([t.to_dict() for t in tasks])

@app.route('/api/tasks', methods=['POST'])
def create_task():
    data = request.get_json()
    task = Task(
        title       = data.get('title', '').strip(),
        description = data.get('description', ''),
        category    = data.get('category', 'Personal'),
        due_date    = date.fromisoformat(data['due_date']) if data.get('due_date') else None,
        due_time    = data.get('due_time'),
        is_special  = data.get('is_special', False),
        repeat      = data.get('repeat', 'none'),
        notes       = data.get('notes', ''),
    )
    db.session.add(task)
    db.session.commit()
    return jsonify(task.to_dict()), 201

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    data = request.get_json()
    for field in ['title','description','category','due_time','is_special','repeat','notes']:
        if field in data:
            setattr(task, field, data[field])
    if 'due_date' in data:
        task.due_date = date.fromisoformat(data['due_date']) if data['due_date'] else None
    if 'is_completed' in data:
        task.is_completed = data['is_completed']
        task.completed_at = datetime.utcnow() if data['is_completed'] else None
    db.session.commit()
    return jsonify(task.to_dict())

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    db.session.delete(task)
    db.session.commit()
    return jsonify({'message': 'deleted'})

# Stats API
@app.route('/api/stats/monthly')
def monthly_stats():
    year  = int(request.args.get('year',  date.today().year))
    month = int(request.args.get('month', date.today().month))
    import calendar
    days_in_month = calendar.monthrange(year, month)[1]
    result = []
    for day in range(1, days_in_month + 1):
        d = date(year, month, day)
        total     = Task.query.filter_by(due_date=d).count()
        completed = Task.query.filter_by(due_date=d, is_completed=True).count()
        result.append({'day': day, 'total': total, 'completed': completed})
    return jsonify(result)

@app.route('/api/stats/overview')
def stats_overview():
    today = date.today()
    week_end = today + timedelta(days=7)
    return jsonify({
        'completed_today': Task.query.filter_by(due_date=today, is_completed=True).count(),
        'pending_today':   Task.query.filter_by(due_date=today, is_completed=False).count(),
        'total_pending':   Task.query.filter_by(is_completed=False).count(),
        'upcoming_week':   Task.query.filter(
                               Task.due_date >= today,
                               Task.due_date <= week_end,
                               Task.is_completed == False
                           ).count(),
    })

# Reminders API
@app.route('/api/reminders', methods=['GET'])
def get_reminders():
    reminders = Reminder.query.order_by(Reminder.reminder_date.asc()).all()
    return jsonify([r.to_dict() for r in reminders])

@app.route('/api/reminders', methods=['POST'])
def create_reminder():
    data = request.get_json()
    r = Reminder(
        title         = data.get('title', '').strip(),
        reminder_type = data.get('reminder_type', 'reminder'),
        reminder_date = date.fromisoformat(data['reminder_date']),
        reminder_time = data.get('reminder_time'),
        notes         = data.get('notes', ''),
        repeat_yearly = data.get('repeat_yearly', False),
    )
    db.session.add(r)
    db.session.commit()
    return jsonify(r.to_dict()), 201

@app.route('/api/reminders/<int:rid>', methods=['DELETE'])
def delete_reminder(rid):
    r = Reminder.query.get_or_404(rid)
    db.session.delete(r)
    db.session.commit()
    return jsonify({'message': 'deleted'})

# Calendar API - tasks/reminders for a month
@app.route('/api/calendar')
def calendar_data():
    year  = int(request.args.get('year',  date.today().year))
    month = int(request.args.get('month', date.today().month))
    import calendar
    days_in_month = calendar.monthrange(year, month)[1]
    data = {}
    for day in range(1, days_in_month + 1):
        d = date(year, month, day)
        tasks     = Task.query.filter_by(due_date=d).count()
        reminders = Reminder.query.filter_by(reminder_date=d).count()
        # Also check yearly repeating reminders
        yearly = Reminder.query.filter_by(repeat_yearly=True).all()
        for rem in yearly:
            if rem.reminder_date.month == month and rem.reminder_date.day == day:
                reminders += 1
        if tasks or reminders:
            data[day] = {'tasks': tasks, 'reminders': reminders}
    return jsonify(data)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
